# Remote Chat Setup Guide

A web chat you run yourself. People join from anywhere through a browser link.
Works on Termux (Android) and Ubuntu. You need the file `server.js`.

---

## PART 1: Termux (Android)

### 1. Install Node.js
```
pkg update && pkg upgrade
pkg install nodejs
```

### 2. Create the project
```
mkdir ~/chat && cd ~/chat
npm init -y
npm install ws
```
Put `server.js` in this folder. If the file is in your Downloads:
```
termux-setup-storage
cp ~/storage/downloads/server.js ~/chat/
```

### 3. Start the chat
```
cd ~/chat
PASSWORD=choosesomething node server.js
```
Test it: open `http://localhost:3000` in Chrome on the same phone.

### 4. Let other people join (tunnel)
Open a second Termux session (swipe from the left edge, tap "New session"):
```
pkg install cloudflared
cloudflared tunnel --url http://localhost:3000
```
It prints a link like `https://random-words.trycloudflare.com`.
Send that link and the password to your friends.

### 5. Keep it running
```
termux-wake-lock
```
Also turn off battery optimization for Termux in Android settings,
or Android may stop it.

---

## PART 2: Ubuntu

### 1. Install Node.js
```
sudo apt update
sudo apt install -y nodejs npm
node -v
```

### 2. Create the project
```
mkdir ~/chat && cd ~/chat
npm init -y
npm install ws
```
Put `server.js` in this folder. If the file is in Downloads:
```
cp ~/Downloads/server.js ~/chat/
```

### 3. Start the chat
```
cd ~/chat
PASSWORD=choosesomething node server.js
```
Test it: open `http://localhost:3000` in your browser.

### 4. Let other people join (tunnel)
Install cloudflared (needs curl: `sudo apt install -y curl`):
```
cd ~
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb
sudo dpkg -i cloudflared.deb
cloudflared --version
```
If `uname -m` shows aarch64/arm64, use `cloudflared-linux-arm64.deb` instead.

Open a second terminal window and run:
```
cloudflared tunnel --url http://localhost:3000
```
It prints a link like `https://random-words.trycloudflare.com`.
Send that link and the password to your friends.

### 5. Optional: always-on server (VPS)
```
sudo ufw allow 3000
sudo npm install -g pm2
cd ~/chat
PASSWORD=choosesomething pm2 start server.js --name chat
pm2 save && pm2 startup
```
People join at `http://YOUR_SERVER_IP:3000`.
This is plain http (not encrypted). For real use, add a domain and HTTPS.

---

## Notes (both systems)

- Keep BOTH windows open: the chat server and the tunnel. Closing either stops the chat.
- The tunnel link changes every time you restart cloudflared.
- Always set PASSWORD, because the link is public to anyone who has it.
- Messages are kept in memory (last 50) and are lost when the server stops.
- To test alone: open the link in two tabs and join with different names.
- Stop the server or tunnel with Ctrl+C.
- Vercel will not work for this (it cannot keep chat connections open).
  Use Render, Railway or Fly.io instead.

## Troubleshooting

- "Cannot find module 'ws'": run `npm install ws` inside the chat folder.
- "address already in use": another copy is running. Stop it, or start with
  `PORT=3001 PASSWORD=... node server.js` and tunnel to port 3001.
- Wrong password: stop the server (Ctrl+C) and restart it with a new PASSWORD.
- Tunnel link does not load: make sure the chat server is running first,
  then wait about 10 seconds.
