// Simple web chat server: Node.js + WebSocket (ws)
// Run:  PASSWORD=mysecret node server.js
const http = require("http");
const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 3000;
const PASSWORD = process.env.PASSWORD || ""; // empty = no password
const history = []; // last 50 messages kept in memory

const PAGE = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#050a08">
<title>REMOTE CHAT // TERMINAL</title>

<style>
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');

:root {
  --bg: #050a08;
  --panel: #09130f;
  --green: #00ff88;
  --cyan: #00eaff;
  --text: #d5ffe8;
  --muted: #648b79;
  --border: #15583b;
  --red: #8F0000;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  height: 100dvh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  background:
    radial-gradient(ellipse at top, #092319 0%, transparent 65%),
    var(--bg);
  color: var(--text);
  font-family: 'Share Tech Mono', monospace;
}

body::before {
  content: "";
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 5;
  background: repeating-linear-gradient(
    transparent 0px, transparent 3px,
    #00ff8808 4px
  );
}

header {
  min-height: 60px;
  padding: 14px 18px;
  background: #07100c;
  border-bottom: 1px solid var(--green);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  box-shadow: 0 0 20px #00ff8815;
}

.logo {
  color: var(--green);
  font-size: 19px;
  font-weight: bold;
  letter-spacing: 2px;
}

.status {
  color: var(--green);
  font-size: 12px;
}

.dot {
  display: inline-block;
  width: 7px;
  height: 7px;
  margin-right: 6px;
  border-radius: 50%;
  background: var(--green);
  box-shadow: 0 0 10px var(--green);
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  50% { opacity: .3; }
}

#login {
  width: min(380px, 90vw);
  margin: auto;
  padding: 25px;
  border: 1px solid var(--green);
  background: #07110df0;
  box-shadow: 0 0 35px #00ff8810;
  position: relative;
}

#login::before {
  content: "SYSTEM ACCESS // AUTH REQUIRED";
  display: block;
  color: var(--muted);
  font-size: 11px;
  margin-bottom: 22px;
  letter-spacing: 1px;
}

h2 {
  color: var(--green);
  font-size: 27px;
  margin: 0 0 8px;
}

.subtitle {
  color: var(--muted);
  font-size: 12px;
  margin-bottom: 25px;
}
.disclaimer {
  color: var(--red);
  font-size: 12px;
  margin-bottom: 25px;
}

input {
  min-width: 0;
  width: 100%;
  padding: 14px;
  background: #030906;
  color: var(--green);
  border: 1px solid var(--border);
  outline: none;
  border-radius: 3px;
  font: inherit;
  font-size: 14px;
}

input:focus {
  border-color: var(--green);
  box-shadow: 0 0 12px #00ff8820;
}

#login input { margin-bottom: 12px; }

button {
  cursor: pointer;
  font: inherit;
  transition: .2s;
}

#join {
  width: 100%;
  padding: 14px;
  color: #00150b;
  background: var(--green);
  border: 1px solid var(--green);
  font-weight: bold;
  letter-spacing: 2px;
  border-radius: 3px;
}

#join:hover {
  background: var(--cyan);
  border-color: var(--cyan);
  box-shadow: 0 0 22px #00eaff50;
}

#err {
  color: #ff6464;
  font-size: 12px;
  margin-top: 12px;
}

#chat {
  display: none;
  flex: 1;
  min-height: 0;
  flex-direction: column;
  width: min(900px, 100%);
  margin: 0 auto;
  border-left: 1px solid var(--border);
  border-right: 1px solid var(--border);
}

.chat-head {
  padding: 14px 16px;
  background: var(--panel);
  border-bottom: 1px solid var(--border);
  display: flex;
  justify-content: space-between;
  gap: 10px;
}

.chat-title { color: var(--cyan); }

#count {
  color: var(--green);
  font-size: 12px;
}

#msgs {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 18px 14px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  background:
    radial-gradient(ellipse at center, #06201655, transparent 75%);
  scrollbar-color: var(--green) var(--bg);
}

.m {
  position: relative;
  width: fit-content;
  max-width: 88%;
  padding: 10px 13px;
  background: #0a1711;
  border: 1px solid #17452f;
  border-left: 3px solid var(--green);
  border-radius: 2px 9px 9px 2px;
  overflow-wrap: anywhere;
  animation: appear .2s ease-out;
}

.m.me {
  align-self: flex-end;
  border-left: 1px solid #087f99;
  border-right: 3px solid var(--cyan);
  background: #071a20;
  border-radius: 9px 2px 2px 9px;
}

.m small {
  display: block;
  color: var(--green);
  font-size: 11px;
  margin-bottom: 5px;
}

.m.me small { color: var(--cyan); }

.sys {
  align-self: center;
  max-width: 95%;
  text-align: center;
  color: var(--cyan);
  font-size: 11px;
  padding: 5px 10px;
  border: 1px dashed #15583b;
  overflow-wrap: anywhere;
}

.sys::before { content: "> "; color: var(--green); }

@keyframes appear {
  from { opacity: 0; transform: translateY(5px); }
  to { opacity: 1; transform: translateY(0); }
}

form {
  display: flex;
  gap: 8px;
  padding: 12px;
  background: var(--panel);
  border-top: 1px solid var(--border);
}

form input { flex: 1; }

#send {
  padding: 0 18px;
  background: var(--green);
  color: #00150b;
  border: 0;
  border-radius: 3px;
  font-weight: bold;
}

#send:active { background: var(--cyan); }

footer {
  text-align: center;
  padding: 9px;
  color: var(--muted);
  font-size: 10px;
  letter-spacing: 1px;
}

@media (min-width: 650px) {
  #chat {
    width: min(900px, 94vw);
    margin: 20px auto;
    border: 1px solid var(--border);
    box-shadow: 0 0 35px #00ff8808;
  }

  #msgs { padding: 24px; }
  .m { max-width: 75%; }
}

@media (max-height: 480px) {
  #login { padding: 14px; }
  .subtitle { margin-bottom: 10px; }
  #login input { padding: 9px; }
  #join { padding: 9px; }
}
</style>
</head>

<body>
<header>
  <div class="logo">> REMOTE_CHAT_</div>
  <div class="status"><span class="dot"></span>NETWORK ACTIVE</div>
</header>

<div id="login">
  <h2>INITIALIZE</h2>
  <div class="subtitle">// Connect. Communicate. Stay anonymous-ish.</div>
  <div class="disclaimer"><strong>// TO JOIN THIS CHAT, YOU HAVE TO ENTER THE CORRECT PASSWORD THAT IS SPECIFIED BY THE ADMIN</strong></div>
  <input id="name" placeholder="Enter username..." maxlength="20"
    autocomplete="nickname">
  <input id="pw" type="password" placeholder="Access password (hi)"
    autocomplete="current-password">
  <button id="join">[ CONNECT ]</button>
  <div id="err" role="status"></div>
</div>

<div id="chat">
  <div class="chat-head">
    <span class="chat-title"># GENERAL_CHANNEL</span>
    <span id="count">0 ONLINE</span>
  </div>
  <div id="msgs" aria-live="polite"></div>
  <form id="f">
    <input id="text" placeholder="Type your message..."
      autocomplete="off" maxlength="500">
    <button id="send" type="submit">SEND ↗</button>
  </form>
</div>

<footer>REMOTE CHAT // ESTABLISHED CONNECTION</footer>

<script>
const $ = id => document.getElementById(id);
let ws, myName = "", reconnecting = false;

function add(cls, name, text) {
  const d = document.createElement("div");
  d.className = cls;

  if (name) {
    const s = document.createElement("small");
    s.textContent = "// " + name;
    d.appendChild(s);
  }

  d.appendChild(document.createTextNode(text));
  $("msgs").appendChild(d);
  $("msgs").scrollTop = $("msgs").scrollHeight;
}

function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING ||
             ws.readyState === WebSocket.OPEN)) return;

  const proto = location.protocol === "https:" ? "wss" : "ws";
  ws = new WebSocket(proto + "://" + location.host);

  ws.onopen = () => {
    ws.send(JSON.stringify({
      type: "join",
      name: myName,
      pw: $("pw").value
    }));
  };

  ws.onmessage = e => {
    let m;
    try { m = JSON.parse(e.data); } catch { return; }

    if (m.type === "denied") {
      $("err").textContent = "ACCESS DENIED // WRONG PASSWORD TRESPASSER!";
      reconnecting = false;
      ws.close();
      return;
    }

    if (m.type === "ok") {
      reconnecting = false;
      $("err").textContent = "";
      $("login").style.display = "none";
      $("chat").style.display = "flex";
      $("msgs").innerHTML = "";
      $("text").focus();
    }

    if (m.type === "msg")
      add(m.name === myName ? "m me" : "m", m.name, m.text);

    if (m.type === "sys") add("sys", "", m.text);

    if (m.type === "count")
      $("count").textContent = m.n + " ONLINE";
  };

  ws.onerror = () => {
    $("err").textContent = "CONNECTION ERROR // CHECK SERVER";
  };

  ws.onclose = () => {
    if ($("chat").style.display === "flex" && !reconnecting) {
      reconnecting = true;
      add("sys", "", "Connection lost. Reconnecting...");
      setTimeout(() => {
        reconnecting = false;
        connect();
      }, 2000);
    }
  };
}

$("join").onclick = () => {
  myName = $("name").value.trim();

  if (!myName) {
    $("err").textContent = "ERROR // USERNAME REQUIRED";
    return;
  }

  $("err").textContent = "CONNECTING TO SERVER...";
  connect();
};

$("name").addEventListener("keydown", e => {
  if (e.key === "Enter") $("join").click();
});

$("pw").addEventListener("keydown", e => {
  if (e.key === "Enter") $("join").click();
});

$("f").onsubmit = e => {
  e.preventDefault();

  const t = $("text").value.trim();

  if (t && ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "msg", text: t }));
    $("text").value = "";
  }
};
</script>
</body>
</html>`;

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(PAGE);
});

const wss = new WebSocketServer({ server });

function broadcast(obj) {
  const data = JSON.stringify(obj);
  for (const c of wss.clients) if (c.joined && c.readyState === 1) c.send(data);
}
const count = () => broadcast({ type: "count", n: [...wss.clients].filter(c => c.joined).length });

wss.on("connection", ws => {
  ws.alive = true;
  ws.on("pong", () => (ws.alive = true));

  ws.on("message", raw => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }

    if (m.type === "join" && !ws.joined) {
      if (PASSWORD && m.pw !== PASSWORD) { ws.send(JSON.stringify({ type: "denied" })); return; }
      ws.name = String(m.name || "anon").slice(0, 20);
      ws.joined = true;
      ws.send(JSON.stringify({ type: "ok" }));
      history.forEach(h => ws.send(JSON.stringify(h)));
      broadcast({ type: "sys", text: ws.name + " joined" });
      count();
    } else if (m.type === "msg" && ws.joined) {
      const msg = { type: "msg", name: ws.name, text: String(m.text).slice(0, 500) };
      history.push(msg);
      if (history.length > 50) history.shift();
      broadcast(msg);
    }
  });

  ws.on("close", () => {
    if (ws.joined) { broadcast({ type: "sys", text: ws.name + " left" }); count(); }
  });
});

// Ping every 30s so tunnels/phones don't silently drop connections
setInterval(() => {
  for (const c of wss.clients) {
    if (!c.alive) { c.terminate(); continue; }
    c.alive = false;
    c.ping();
  }
}, 30000);

server.listen(PORT, () => console.log("Chat running on http://localhost:" + PORT));
